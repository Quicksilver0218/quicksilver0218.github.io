npm i
xdg-open http://localhost:3000
npx next start