call npm i
start http://localhost:3000
npx next start