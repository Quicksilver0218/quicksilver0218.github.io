docker build . -t alphazero_tic_tac_toe_demo
docker run -it --rm --gpus all alphazero_tic_tac_toe_demo