from games.mnk_game.config import RULE, MODEL_PATH, MCTS_SIMULATIONS, C_PUCT
import games.mnk_game.game as game
import re
import alphazerobase as az

state = game.RuntimeState(RULE)
state_structure = state.get_structure()
turn_actor = 1
actions = state.get_available_actions(turn_actor)
tree = None
model_output_cache = {}
model = az.ModelUtils.load_model(MODEL_PATH)
logs = None
# logs = []
while True:
    print("Select Faction (X: First, O: Next):")
    s = input().upper()
    if s == "X":
        player_faction = 1
    elif s == "O":
        player_faction = -1
    else:
        continue
    break
print(state)
while True:
    if player_faction == turn_actor:
        while True:
            print("Your Turn:")
            s = input().upper()
            m = re.search("([A-Z]+)([0-9]+)", s)
            if m is None:
                continue
            s = m.group(1)
            x = 0
            for i, c in enumerate(s):
                x += (ord(c) - ord("A")) * pow(26, len(s) - 1 - i)
            s = m.group(2)
            y = int(s) - 1
            p = y * RULE.n + x
            valid = False
            for action in actions:
                if action.id == p:
                    selected_action = action
                    valid = True
                    break
            if valid:
                break
            print("Invalid Action")
        if tree is not None:
            tree = az.Mcts.get_subtree(tree, state.get_normalized_action(selected_action))
        result, turn_actor, actions = state.perform_action(selected_action, turn_actor)
    else:
        print("AI's Turn:")
        if tree is None:
            tree = az.Mcts.create_node(state, state_structure, turn_actor, actions, model_output_cache, model, logs)[0]
        action = az.Mcts.mcts(tree, state, state_structure, MCTS_SIMULATIONS, model_output_cache, model, C_PUCT, logs=logs)
        runtime_action = state.get_runtime_action(action)
        result, turn_actor, actions = state.perform_action(runtime_action, turn_actor)
        tree = az.Mcts.get_subtree(tree, action)
        # print("\n".join(logs))
        # logs.clear()
        print(runtime_action.to_string(state.get_structure()))
    print(state)
    if result is not None:
        value = result * player_faction
        if value > 0:
            print("You Win")
        elif value < 0:
            print("You Lose")
        else:
            print("Draw")
        break