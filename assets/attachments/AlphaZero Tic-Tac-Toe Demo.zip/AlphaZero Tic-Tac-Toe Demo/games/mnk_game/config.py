import games.mnk_game.game as game

RULE = game.Rule(3, 3, 3)
MODEL_PATH = "games/mnk_game/models/%d_%d_%d" % (RULE.m, RULE.n, RULE.k)
MCTS_SIMULATIONS = 20
C_PUCT = 4.