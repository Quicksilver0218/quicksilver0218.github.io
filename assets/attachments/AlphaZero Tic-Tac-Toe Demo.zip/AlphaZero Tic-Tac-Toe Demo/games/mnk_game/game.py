from __future__ import annotations
from typing import Tuple, List
from typing_extensions import override

class StateUtils:
    @staticmethod
    def normalized_to_runtime_index(i: int, rotation: int, m: int, n: int) -> int:
        if m != n and rotation & 1 == 1:
            raise Exception("Invalid rotation in rectangular space.")
        if rotation == 0:
            return i
        if rotation == 1:
            return m - 1 - i // m + i % m * m
        if rotation == 2:
            return m * n - 1 - i
        if rotation == 3:
            return i // m + (m - 1 - i % m) * m
        if rotation == 4:
            return n - 1 - i % n + i // n * n
        if rotation == 5:
            return i // m + i % m * m
        if rotation == 6:
            return i % n + (m - 1 - i // n) * n
        if rotation == 7:
            return m - 1 - i // m + (m - 1 - i % m) * m
        raise Exception("Invalid rotation.")
    
    @staticmethod
    def runtime_to_normalized_index(i: int, rotation: int, m: int, n: int) -> int:
        if rotation == 1:
            return StateUtils.normalized_to_runtime_index(i, 3, m, n)
        if rotation == 3:
            return StateUtils.normalized_to_runtime_index(i, 1, m, n)
        return StateUtils.normalized_to_runtime_index(i, rotation, m, n)
    
    @staticmethod
    def get_symbol(faction: int) -> str:
        if faction == 1:
            return "X"
        if faction == -1:
            return "O"
        return "·"

class Rule:
    def __init__(self, m: int, n: int, k: int):
        self.m = m
        self.n = n
        self.k = k

import alphazerobase as az

class StateStructure(az.IStateStructure):
    def __init__(self, m: int, n: int):
        self.m = m
        self.n = n

    @override
    def get_policy_size(self) -> int:
        return self.m * self.n

class Action(az.Action):
    @override
    def to_string(self, state_structure: StateStructure) -> str:
        return chr(self.id % state_structure.n + ord("A")) + str(self.id // state_structure.m + 1)

import tensorflow as tf
import base64

class EncodedState(az.IEncodedState):
    def __init__(self, state: int):
        self.state = state
    
    @override
    def get_model_input(self, state_structure: StateStructure) -> tf.Tensor:
        result = [[[0.] * 2 for _ in range(state_structure.n)] for _ in range(state_structure.m)]
        state = self.state
        for i in range(state_structure.m):
            for j in range(state_structure.n):
                s = state % 3
                if s == 1:
                    result[i][j][0] = 1.
                elif s == 2:
                    result[i][j][1] = 1.
                state //= 3
        return tf.constant(result)
    
    @override
    def __hash__(self) -> int:
        return hash(self.state)
    
    @override
    def __eq__(self, other) -> bool:
        return isinstance(other, EncodedState) and other.state == self.state
    
    @override
    def __str__(self) -> str:
        return base64.b64encode(self.state.to_bytes(13, 'little')).decode("ascii")

import numpy as np

class RuntimeState(az.IRuntimeState):
    def __init__(self, rule: Rule):
        self.state = np.zeros((rule.m, rule.n), dtype=int)
        self.rule = rule
        self.rotation = 0
    
    @override
    def reset(self):
        self.state = np.zeros(self.state.shape, dtype=int)
        self.rotation = 0
    
    @override
    def get_encoded_state(self, faction: int) -> EncodedState:
        state = 0
        for i in range(self.state.shape[0]):
            for j in range(self.state.shape[1]):
                index = StateUtils.normalized_to_runtime_index(i * self.state.shape[1] + j, self.rotation, self.state.shape[0], self.state.shape[1])
                s = int(self.state[index // self.state.shape[1]][index % self.state.shape[1]]) * faction
                if s == -1:
                    s = 2
                state += s * 3 ** (i * self.state.shape[1] + j)
        return EncodedState(state)
    
    @override
    def get_normalized_action(self, runtime_action: Action) -> Action:
        return Action(StateUtils.runtime_to_normalized_index(runtime_action.id, self.rotation, self.state.shape[0], self.state.shape[1]))
    
    @override
    def get_runtime_action(self, normalized_action: Action) -> Action:
        return Action(StateUtils.normalized_to_runtime_index(normalized_action.id, self.rotation, self.state.shape[0], self.state.shape[1]))
    
    @override
    def get_available_actions(self, faction: int) -> List[Action]:
        actions = []
        for i in range(self.state.shape[0] * self.state.shape[1]):
            if self.state[i // self.state.shape[1]][i % self.state.shape[1]] == 0:
                actions.append(Action(i))
        return actions
    
    @override
    def perform_action(self, action: Action, faction: int) -> Tuple[int|None, int, List[Action]]:
        x = action.id % self.state.shape[1]
        y = action.id // self.state.shape[1]
        self.state[y][x] = faction
        self.update_rotation()
        directions = np.asarray([[0, 1], [1, 1], [1, 0], [1, -1]])
        for direction in directions:
            length = 0
            for i in range(-self.rule.k + 1, self.rule.k):
                if i == 0:
                    length += 1
                    if length == self.rule.k:
                        return (faction, 0, None)
                else:
                    p = direction * i + np.asarray([y, x])
                    if p[0] >= 0 and p[0] < self.state.shape[0] and p[1] >= 0 and p[1] < self.state.shape[1] and self.state[p[0]][p[1]] == faction:
                        length += 1
                        if length == self.rule.k:
                            return (faction, 0, None)
                    else:
                        length = 0
                        if i > 0:
                            break
        full = True
        for i in range(self.state.shape[0]):
            for j in range(self.state.shape[1]):
                if self.state[i][j] == 0:
                    full = False
        if full:
            return (0, 0, None)
        return (None, -faction, self.get_available_actions(-faction))
    
    @override
    def get_structure(self) -> StateStructure:
        return StateStructure(self.state.shape[0], self.state.shape[1])
    
    @override
    def clone(self) -> RuntimeState:
        s = RuntimeState(self.rule)
        for i in range(self.state.shape[0]):
            for j in range(self.state.shape[1]):
                s.state[i][j] = self.state[i][j]
        s.rotation = self.rotation
        return s
    
    @override
    def __str__(self):
        return "  %s\n%s" % ("".join(["%-2s" % chr(i + ord("A")) for i in range(self.state.shape[1])]), "\n".join(["%d %s" % (i + 1, " ".join([StateUtils.get_symbol(f) for f in self.state[i]])) for i in range(self.state.shape[0])]))
    
    def update_rotation(self):
        if self.state.shape[0] == self.state.shape[1]:
            flags = 255
        else:
            flags = 85
        for i in range(self.state.shape[0] * self.state.shape[1]):
            max_s = float("-inf")
            new_flags = 0
            for r in range(8):
                bit = 1 << r
                if flags & bit != 0:
                    ri = StateUtils.normalized_to_runtime_index(i, r, self.state.shape[0], self.state.shape[1])
                    s = self.state[ri // self.state.shape[1]][ri % self.state.shape[1]]
                    if s == max_s:
                        new_flags += bit
                    elif s > max_s:
                        max_s = s
                        new_flags = bit
            flags = new_flags
            flag_count = 0
            while new_flags != 0 and flag_count < 2:
                flag_count += 1
                new_flags &= new_flags - 1
            if flag_count == 1:
                break
        for i in range(8):
            if (flags & 1 << i) != 0:
                break
        self.rotation = i