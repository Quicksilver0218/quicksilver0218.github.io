from __future__ import annotations
from typing import Tuple, List, Dict
from abc import ABC, abstractmethod
from keras import layers, models, regularizers
import math
import random
import numpy as np
import tensorflow as tf
import keras

class IStateStructure(ABC):
    @abstractmethod
    def get_policy_size(self) -> int:
        pass

class Action:
    def __init__(self, id: int):
        self.id = id
    
    def to_string(self, state_structure: IStateStructure) -> str:
        return str(self.id)

class IEncodedState(ABC):
    @abstractmethod
    def get_model_input(self, state_structure: IStateStructure, faction: int) -> tf.Tensor:
        pass
    
    @abstractmethod
    def __hash__(self) -> int:
        pass
    
    @abstractmethod
    def __eq__(self, other) -> bool:
        pass

    @abstractmethod
    def __str__(self) -> str:
        pass

class IRuntimeState(ABC):
    @abstractmethod
    def reset(self):
        pass

    @abstractmethod
    def get_encoded_state(self, faction: int) -> IEncodedState:
        pass
    
    @abstractmethod
    def get_normalized_action(self, runtime_action: Action) -> Action:
        pass
    
    @abstractmethod
    def get_runtime_action(self, normalized_action: Action) -> Action:
        pass
    
    @abstractmethod
    def get_available_actions(self, faction: int) -> List[Action]:
        pass
    
    @abstractmethod
    def perform_action(self, action: Action, faction: int) -> Tuple[int|None, int, List[Action]]:
        pass

    @abstractmethod
    def get_structure(self) -> IStateStructure:
        pass
    
    @abstractmethod
    def clone(self) -> IRuntimeState:
        pass
    
    @abstractmethod
    def __str__(self) -> str:
        pass

class NodeAction:
    def __init__(self, action: Action, priority: float):
        self.action = action
        self.priority = priority
        self.value_sum = 0.
        self.visit_count = 0
        self.next_node: Node = None
        self.solved_value: int | None = None

    def get_mean_value(self) -> float:
        if self.visit_count == 0:
            return 0
        return self.value_sum / self.visit_count

class Node:
    def __init__(self, available_actions: Dict[int, NodeAction], faction: int):
        self.available_actions = available_actions
        self.faction = faction

class ModelUtils:    
    @staticmethod
    def save_model(model: keras.Model, path: str, extension = "keras"):
        model.save("%s.%s" % (path, extension))
    
    @staticmethod
    def load_model(path: str, extension = "keras") -> keras.Model:
        return models.load_model("%s.%s" % (path, extension))

class NeuralNetwork:
    def __init__(self, input_shape: Tuple[int], policy_size: int, conv_layer_filter_count = 256, residual_layer_count = 19, value_head_layer_size = 256, reg_const = .0001):
        self.input_shape = input_shape
        self.policy_size = policy_size
        self.conv_layer_filter_count = conv_layer_filter_count
        self.residual_layer_count = residual_layer_count
        self.value_head_layer_size = value_head_layer_size
        self.reg_const = reg_const

    def _residual_layer(self, input_block: tf.Tensor, filters: int, kernel_size: int) -> tf.Tensor:
        x = self._conv_layer(input_block, filters, kernel_size)
        x = layers.Conv2D(filters=filters, kernel_size=kernel_size, padding="same", kernel_regularizer=regularizers.L2(self.reg_const))(x)
        x = layers.BatchNormalization(axis=kernel_size)(x)
        x = layers.add([input_block, x])
        return layers.ReLU()(x)

    def _conv_layer(self, x: tf.Tensor, filters: int, kernel_size: int) -> tf.Tensor:
        x = layers.Conv2D(filters=filters, kernel_size=kernel_size, padding="same", kernel_regularizer=regularizers.L2(self.reg_const))(x)
        x = layers.BatchNormalization(axis=kernel_size)(x)
        return layers.ReLU()(x)

    def _value_head(self, x: tf.Tensor, layer_size: int) -> tf.Tensor:
        x = self._conv_layer(x, 1, 1)
        x = layers.Flatten()(x)
        x = layers.Dense(layer_size, kernel_regularizer=regularizers.L2(self.reg_const))(x)
        x = layers.ReLU()(x)
        return layers.Dense(1, activation="tanh", kernel_regularizer=regularizers.L2(self.reg_const), name="value_head")(x)

    def _policy_head(self, x: tf.Tensor) -> tf.Tensor:
        x = self._conv_layer(x, 2, 1)
        x = layers.Flatten()(x)
        return layers.Dense(self.policy_size, kernel_regularizer=regularizers.L2(self.reg_const), name="policy_head")(x)

    def build_model(self) -> keras.Model:
        main_input = keras.Input(shape=self.input_shape, name="main_input")
        x = self._conv_layer(main_input, self.conv_layer_filter_count, 3)

        for _ in range(self.residual_layer_count):
            x = self._residual_layer(x, self.conv_layer_filter_count, 3)

        vh = self._value_head(x, self.value_head_layer_size)
        ph = self._policy_head(x)

        return keras.Model(inputs=[main_input], outputs=[vh, ph])

class Mcts:
    @staticmethod
    def create_node(state: IRuntimeState, state_structure: IStateStructure, faction: int, available_actions: List[Action], model_output_cache: Dict[IEncodedState, Tuple[float, Dict[int, float]]], model: keras.Model, logs: List[str] | None = None) -> Tuple[Node, float]:
        if logs is not None:
            logs.append("Creating New Node. Available Actions of Player %d: %s" % (faction, ", ".join([action.to_string(state_structure) for action in available_actions])))
        available_node_actions: Dict[int, NodeAction] = {}
        encoded_state = state.get_encoded_state(faction)
        if encoded_state in model_output_cache:
            value, priorities = model_output_cache[encoded_state]
            for action in available_actions:
                normalized_action = state.get_normalized_action(action)
                node_action = NodeAction(normalized_action, priorities[normalized_action.id])
                available_node_actions[normalized_action.id] = node_action
            if logs is not None:
                logs.append("Model outputs found in cache.")
        else:
            model_input = encoded_state.get_model_input(state_structure)
            if logs is not None:
                logs.append("Neural Network Input: %s" % model_input)
            value, priority_logits = list(zip(*model(np.asarray([model_input]))))[0]
            value = float(value[0])
            if logs is not None:
                logs.append("Neural Network Output Priority Logits: %s" % priority_logits)
            max_logit = float("-inf")
            priority_sum = 0.
            for action in available_actions:
                normalized_action = state.get_normalized_action(action)
                node_action = NodeAction(normalized_action, float(priority_logits[normalized_action.id]))
                available_node_actions[normalized_action.id] = node_action
                if node_action.priority > max_logit:
                    max_logit = node_action.priority
            for node_action in available_node_actions.values():
                node_action.priority = math.exp(node_action.priority - max_logit)
                priority_sum += node_action.priority
            priorities = {}
            for node_action in available_node_actions.values():
                node_action.priority /= priority_sum
                priorities[node_action.action.id] = node_action.priority
            model_output_cache[encoded_state] = (value, priorities)
        if logs is not None:
            logs.append("Actions Priority: %s" % ", ".join(["%s: %f" % (state.get_runtime_action(node_action.action).to_string(state_structure), node_action.priority) for node_action in available_node_actions.values()]))
        return (Node(available_node_actions, faction), value)

    @staticmethod
    def simulate(state: IRuntimeState, state_structure: IStateStructure, node: Node, model_output_cache: Dict[IEncodedState, Tuple[float, Dict[int, float]]], model: keras.Model, c_puct: float, dirichlet_noise_ratio = 0., dirichlet_alpha = 0., logs: List[str] | None = None) -> Tuple[float, bool, NodeAction]:
        # Select
        if logs is not None:
            logs.append("Start Selection (C puct: %f, Dirichlet Noise Ratio: %f, Dirichlet Alpha: %f)" % (c_puct, dirichlet_noise_ratio, dirichlet_alpha))
        available_actions = list(node.available_actions.values())
        selected_action = available_actions[0]
        if len(available_actions) > 1:
            if dirichlet_noise_ratio > 0 and dirichlet_alpha > 0:
                dirichlet_noises = np.random.dirichlet([dirichlet_alpha] * len(available_actions))
                priorites = [node_action.priority * (1 - dirichlet_noise_ratio) + float(noise) * dirichlet_noise_ratio for node_action, noise in zip(available_actions, dirichlet_noises)]
            else:
                priorites = [node_action.priority for node_action in available_actions]
            max_ucb = float("-inf")
            for node_action, priority in zip(available_actions, priorites):
                ucb = node_action.get_mean_value() * node.faction + c_puct * priority * math.sqrt(sum([node_action.visit_count for node_action in available_actions]) + 1) / (node_action.visit_count + 1)
                if logs is not None:
                    logs.append("Action %s UCB: %f (Value: %f, Priority: %f, Visit Count: %d)" % (state.get_runtime_action(node_action.action).to_string(state_structure), ucb, node_action.get_mean_value() * node.faction, priority, node_action.visit_count))
                if ucb > max_ucb:
                    max_ucb = ucb
                    selected_action = node_action
        else:
            if logs is not None:
                logs.append("Only 1 action available.")
        if logs is not None:
            logs.append("Action %s is selected for Player %d." % (state.get_runtime_action(selected_action.action).to_string(state_structure), node.faction))
        selected_action.visit_count += 1
        if selected_action.solved_value is not None:
            selected_action.value_sum += selected_action.solved_value # Backup
            if logs is not None:
                logs.append("The action has already been solved. Value: %d" % selected_action.solved_value)
            return (selected_action.solved_value, True, selected_action)
        runtime_action = state.get_runtime_action(selected_action.action)
        result, faction, available_actions = state.perform_action(runtime_action, node.faction)
        if logs is not None:
            logs.append("New State after Action Performed:\n%s" % state)
        if selected_action.next_node is not None:
            value, solved, next_selected_action = Mcts.simulate(state, state_structure, selected_action.next_node, model_output_cache, model, c_puct, logs=logs)
            selected_action.value_sum += value # Backup
            if solved:
                if next_selected_action.solved_value * faction > 0:
                    selected_action.solved_value = next_selected_action.solved_value
                else:
                    max_value = -1
                    for node_action in selected_action.next_node.available_actions.values():
                        if node_action.solved_value is None:
                            solved = False
                            break
                        if node_action.solved_value == 0:
                            max_value = 0
                    if solved:
                        selected_action.solved_value = max_value * faction
            return (value, solved, selected_action)
        
        if result is None:
            # Expand and Evaluate
            if logs is not None:
                logs.append("Simulation ended with leaf node reached.")
            next_node, value = Mcts.create_node(state, state_structure, faction, available_actions, model_output_cache, model, logs)
            if logs is not None:
                logs.append("Neural Network Output Value: %f" % value)
            selected_action.next_node = next_node
            selected_action.value_sum += value * faction # Backup
            return (value * faction, False, selected_action)
        
        # Evaluate
        if logs is not None:
            logs.append("Simulation Ended with Game Over. Result: %d" % result)
        if result != 0:
            result /= abs(result)
        selected_action.value_sum += result # Backup
        selected_action.solved_value = result
        return (result, True, selected_action)

    # Return normalized action
    @staticmethod
    def mcts(tree: Node, state: IRuntimeState, state_structure: IStateStructure, simulation_count: int, model_output_cache: Dict[IEncodedState, Tuple[float, Dict[int, float]]], model: keras.Model, c_puct: float, temperature = 0., dirichlet_noise_ratio = 0., dirichlet_alpha = 0., logs: List[str] | None = None) -> Action:
        if logs is not None:
            logs.append("Start MCTS")
        available_actions = list(tree.available_actions.values())
        has_win_action = False
        for i in range(simulation_count):
            if logs is not None:
                logs.append("Simulation %d on State:\n%s" % (i + 1, state))
            simulation_state = state.clone()
            _, solved, selected_action = Mcts.simulate(simulation_state, state_structure, tree, model_output_cache, model, c_puct, dirichlet_noise_ratio, dirichlet_alpha, logs)
            if solved:
                if not has_win_action and selected_action.solved_value * tree.faction > 0:
                    if logs is not None:
                        logs.append("Root node solved with win action.")
                    if temperature == 0:
                        if logs is not None:
                            logs.append("Selected Win Action: %s" % state.get_runtime_action(selected_action.action).to_string(state_structure))
                        return selected_action.action
                    has_win_action = True
                draw_actions = []
                for node_action in available_actions:
                    if node_action.solved_value is None:
                        solved = False
                        break
                    if node_action.solved_value == 0:
                        draw_actions.append(node_action)
                if solved:
                    if logs is not None:
                        logs.append("Root node completely solved.")
                    break
        if logs is not None:
            logs.append("MCTS ended.")
        if len(available_actions) == 1:
            selected_action = available_actions[0].action
            if logs is not None:
                logs.append("Only 1 action available. Selected Action: %s" % state.get_runtime_action(selected_action).to_string(state_structure))
            return selected_action
        if logs is not None:
            logs.append("Actions Visit Count: %s" % ", ".join(["%s: %d" % (state.get_runtime_action(node_action.action).to_string(state_structure), node_action.visit_count) for node_action in available_actions]))
            logs.append("Select Action with Temperature %f" % temperature)
        if temperature == 0:
            if solved and len(draw_actions) > 0:
                available_actions = draw_actions
                if logs is not None:
                    logs.append("Remove lose actions from available actions. Remaining Draw actions: %s" % ", ".join(["%s" % state.get_runtime_action(node_action.action).to_string(state_structure) for node_action in draw_actions]))
            max_visit_count = 0
            selected_actions = []
            for node_action in available_actions:
                if node_action.visit_count > max_visit_count:
                    max_visit_count = node_action.visit_count
                    selected_actions = [node_action]
                elif node_action.visit_count == max_visit_count:
                    selected_actions.append(node_action)
            selected_action = random.choice(selected_actions).action
            if logs is not None:
                logs.append("Selected Action: %s" % state.get_runtime_action(selected_action).to_string(state_structure))
            return selected_action
        scaled_visit_counts = [node_action.visit_count ** (1 / temperature) for node_action in available_actions]
        s = sum(scaled_visit_counts)
        p = [c / s for c in scaled_visit_counts]
        selected_action = np.random.choice(available_actions, 1, p=p)[0].action
        if logs is not None:
            logs.append("Actions Selection Probability: %s" % ", ".join(["%s: %f" % (state.get_runtime_action(node_action.action).to_string(state_structure), c) for node_action, c in zip(available_actions, p)]))
            logs.append("Selected Action: %s" % state.get_runtime_action(selected_action).to_string(state_structure))
        return selected_action
    
    @staticmethod
    def get_subtree(tree: Node, action: Action) -> Node:
        return tree.available_actions[action.id].next_node